/**
 * 对话 UI 状态：对话条目 + 发送锁。
 *
 * 纯 Pinia store，无任何 Cordis / bridge 依赖。
 * 初始化（从 bridge.boot() 恢复历史 + 订阅 onEvent）由 main.ts 负责。
 */

import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { ChatEntry } from '@web/types/view-model.ts'
import type { SessionEvent } from '@session'

export const useChatStore = defineStore('chat', () => {
  const entries = ref<readonly ChatEntry[]>([])
  const pending = ref(false)

  function append(entry: ChatEntry): void {
    entries.value = [...entries.value, entry]
  }

  function appendEvent(event: SessionEvent): void {
    append({ kind: 'event', event })
  }

  function appendError(text: string): void {
    append({ kind: 'error', text })
  }

  function setPending(value: boolean): void {
    pending.value = value
  }

  function clear(): void {
    entries.value = []
  }

  return { entries, pending, append, appendEvent, appendError, setPending, clear }
})
