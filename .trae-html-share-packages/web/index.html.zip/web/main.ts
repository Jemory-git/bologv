import './styles/index.scss'
import { createPinia } from 'pinia'
import { createRoot } from '@cordis'
import { BRIDGE_SERVICE, electronBridge } from './plugins/core/electron-bridge.ts'
import { pluginRegistry } from './plugins/core/plugin-registry.ts'
import { pluginsPage } from './plugins/plugins-page/plugins-page.ts'
import { RENDERER_SERVICE, vueRenderer } from './renderer/vue-renderer.ts'
import type { RendererService } from './renderer/vue-renderer.ts'
import type { BridgeService } from './plugins/core/electron-bridge.ts'
import { useChatStore } from './stores/chat.ts'

async function main(): Promise<void> {
  const rootCtx = createRoot()
  window.addEventListener('beforeunload', () => rootCtx.close())

  // Cordis 插件装配顺序：
  //   vueRenderer → electronBridge → pluginRegistry（需在 fixed 插件之前） → pluginsPage
  await rootCtx.use(vueRenderer)
  await rootCtx.use(electronBridge)
  await rootCtx.use(pluginRegistry)
  await rootCtx.use(pluginsPage)

  const pinia = createPinia()
  const chat = useChatStore(pinia) // 未挂进 app 时需显式传入 pinia 实例
  const bridge = rootCtx.require<BridgeService>(BRIDGE_SERVICE)

  // —— 初始化（boot + 恢复历史 + 订阅事件）——
  // await 到 boot 完成（无论 resolve 还是 reject），再 mount Vue app。
  // 这样首帧就是正确状态：要么有恢复历史，要么显示启动错误——不会先空白再闪跳。
  try {
    const info = await bridge.boot()
    if (info.restored.length > 0) {
      chat.append({ kind: 'notice', text: `已从日志恢复 ${info.restored.length} 条事件。` })
      for (const event of info.restored) chat.appendEvent(event)
    }
    bridge.onEvent((event) => chat.appendEvent(event))
  } catch (error) {
    chat.appendError(`启动失败：${String(error)}`)
  }

  // —— 挂载 Vue app（pinia 通过 setup 回调注入）——
  const renderer = rootCtx.require<RendererService>(RENDERER_SERVICE)
  renderer.mount((app) => app.use(pinia))
}

void main()
