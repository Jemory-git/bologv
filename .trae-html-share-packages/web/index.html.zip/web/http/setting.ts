import { http } from './fetch';
import type { Vendor } from '@agent-assistant'

export function getVendors<T>() {
    return http.get<T>('/api/models')
}

export function setVendors<T>(body: { vendors: Vendor[] }) {
    return http.put<T>('/api/models', body)
}
