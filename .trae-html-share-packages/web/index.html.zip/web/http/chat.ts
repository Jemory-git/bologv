import { http } from './fetch';

export function chat<T>(params: { text: string }) {
    return http.post<T>('/api/chat', params)
}
