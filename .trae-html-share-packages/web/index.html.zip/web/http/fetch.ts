/**
 * 前端 HTTP 客户端。
 *
 * 纯 transport 层：发请求 + 解析 JSON 返回。
 * 不解释 service 层的业务契约（code / msg / errCode），
 * 那些由调用方自己根据需要判断。
 *
 * 返回 tuple [Error | null, Body<T>, Response]：
 *   - err !== null  → transport 层失败（网络/DNS/HTTP 非 200）
 *   - err === null  → 有完整 JSON 响应，调用方自己判 body.code
 *
 * 调用方：`const [err, body] = await http.post(...)`，无 try/catch。
 *
 * base URL 用 window.location.origin：
 *   - 开发环境 → Vite dev server，由 vite proxy 转发 /api → Koa
 *   - 生产环境 → Electron 内嵌的 Koa（serve 静态 + /api）
 */

type Body<T> = ResponseBody<T>

type AppFetchReturn<T> = Promise<[Error | null, Body<T>, Response]>

type AppFetchOptions = {
  url: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  params?: Record<string, any>
  body?: any
  headers?: Record<string, string>
  stream?: boolean
}

export async function appFetch<T>(options: AppFetchOptions): AppFetchReturn<T> {
  const url = new URL(options.url, window.location.origin)

  if (options.params) {
    Object.entries(options.params).forEach(([k, v]) => {
      if (v != undefined && v !== '') {
        url.searchParams.set(k, v) // URLSearchParams.set() 自动 encode
      }
    })
  }

  const isFormData = options.body instanceof FormData

  const res = await fetch(url.toString(), {
    method: options.method || 'GET',
    headers: {
      ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
      ...(options.headers || {}),
    },
    body: options.body && options.method !== 'GET'
      ? isFormData ? options.body : JSON.stringify(options.body)
      : undefined,
  })

  // 流式响应：不走 JSON 解析，直接把 Response 交给调用方处理
  if (options.stream) {
    return [null, { code: 0, msg: '', data: undefined as unknown as T } as Body<T>, res]
  }

  // HTTP 层错误
  if (!res.ok) {
    return [
      new Error(`HTTP ${res.status}`),
      { code: -1, msg: '', data: undefined as unknown as T } as Body<T>,
      res,
    ]
  }

  return [null, (await res.json()) as Body<T>, res]
}

export const http = {
    get<T>(url: string, params?: Record<string, any>): AppFetchReturn<T> {
        const options: AppFetchOptions = {
            url,
            method: 'GET',
            params
        }
        return appFetch(options)
    },
    post<T>(url: string, body?: any): AppFetchReturn<T> {
        const options: AppFetchOptions = {
            url,
            method: 'POST',
            body
        }
        return appFetch(options)
    },
    put<T>(url: string, body?: any): AppFetchReturn<T> {
        const options: AppFetchOptions = {
            url,
            method: 'PUT',
            body
        }
        return appFetch(options)
    },
    delete<T>(url: string, params?: Record<string, any>): AppFetchReturn<T> {
        const options: AppFetchOptions = {
            url,
            method: 'DELETE',
            params
        }
        return appFetch(options)
    },
    streamGet<T>(url: string, params?: Record<string, any>): AppFetchReturn<T> {
        const options: AppFetchOptions = {
            url,
            method: 'GET',
            params,
            stream: true
        }
        return appFetch(options)
    },
    streamPost<T>(url: string, body?: any): AppFetchReturn<T> {
        const options: AppFetchOptions = {
            url,
            method: 'POST',
            body,
            stream: true
        }
        return appFetch(options)
    }
}