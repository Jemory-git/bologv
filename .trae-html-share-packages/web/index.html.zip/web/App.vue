<script setup lang="ts">
/**
 * 组合根：把插件状态接到布局组件上。
 * App.vue 本身不持有业务状态，只负责组装 slot 和模态窗。
 */
import { ref } from 'vue'
import { useChatStore } from '@web/stores/chat.ts'

import AppShell from './components/layout/AppShell.vue'
import Sidebar from './components/layout/Sidebar.vue'
import StatusBar from './components/layout/StatusBar.vue'
import TitleBar from './components/layout/TitleBar.vue'
import Modal from './components/modal/Modal.vue'
import Main from './views/Main.vue'
import ModelModal from './views/ModelModal.vue'

import type { SessionSummary } from './types/view-model.ts'

const chat = useChatStore()

type ModalKind = 'model' | null
const activeModal = ref<ModalKind>(null)

const sessions = ref<SessionSummary[]>([
  { id: 'default', title: '当前会话', subtitle: '' },
])
</script>

<template>
  <AppShell>
    <template #titlebar>
      <TitleBar model="mock" :pending="chat.pending" />
    </template>
    <template #sidebar>
      <Sidebar :sessions="sessions" active-id="default" @open-model="activeModal = 'model'" />
    </template>
    <Main />
    <template #statusbar>
      <StatusBar />
    </template>
  </AppShell>

  <Modal v-if="activeModal === 'model'" title="配置模型" width="92rem" height="68rem" @close="activeModal = null">
    <ModelModal />
  </Modal>
</template>
