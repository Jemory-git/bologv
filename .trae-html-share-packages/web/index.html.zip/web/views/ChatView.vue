<script setup lang="ts">
/**
 * 对话视图：自包含发送逻辑，状态从 Pinia chat store 读。
 *
 * - 历史 entries / pending：useChatStore()
 * - 发消息：直接 http.post('/api/chat')，tuple 返回无 try/catch
 *   （bridge.onEvent 推送会把本轮 events 统一填进 store，这里不关心返回值）
 */
import Header from '@web/components/conversation/header.vue'
import Input from '@web/components/conversation/input.vue'
import Body from '@web/components/conversation/body.vue'
import { chat as httpChat } from '@web/http/chat.ts'
import { useChatStore } from '@web/stores/chat.ts'

const chat = useChatStore()

async function send(text: string): Promise<void> {
  const value = text.trim()
  if (value === '' || chat.pending) return
  chat.setPending(true)
  const [err, body] = await httpChat({ text: value })
  if (err) {
    chat.appendError(`请求失败：${err.message}`)
  } else if (body.code !== 0) {
    chat.appendError(`请求失败：${body.msg || 'api error'}`)
  }
  chat.setPending(false)
}
</script>

<template>
  <section class="chat-view">
    <Header title="当前会话" model="mock" :pending="chat.pending" />

    <Body :entries="chat.entries" :pending="chat.pending" @suggest="send($event)" />
    <Input :pending="chat.pending" @send="send($event)" />
  </section>
</template>

<style scoped lang="scss">
.chat-view {
  display: flex;
  flex-direction: column;
  min-height: 0;
  height: 100%;
}
</style>
