<script setup lang="ts">
/**
 * 主区域：消费 sidebar.panels 配对插槽的 active view。
 *
 * 从 PairSlot.active 直接拿到当前选中的 view，
 * null 表示回到会话页（ChatView，自包含状态）。
 */
import ChatView from '@web/views/ChatView.vue'
import { sidebarPanels } from '@web/slots/pair/sidebar-panels.ts'

const activePair = sidebarPanels.active.value
</script>

<template>
  <ChatView v-if="activePair === null" />
  <component
    v-else
    :is="activePair.view.component"
    :key="activePair.id"
    v-bind="activePair.view.props()"
  />
</template>
