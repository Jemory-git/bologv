/**
 * 渲染进程侧的 IPC 契约：preload 通过 contextBridge 把 window.bologui 暴露给页面。
 *
 * 通道名和载荷类型必须与 apps/electron/src/types/ipc.ts 保持一致——
 * BootInfo 是主进程 BootResponse 的渲染侧投影（只保留渲染进程需要的字段）。
 */
import type { SessionEvent } from '@session'

/** boot 通道的返回：插件列表、会话路径、被恢复的历史事件。 */
export interface BootInfo {
  plugins: string[]
  sessionPath: string
  workingDir: string
  restored: SessionEvent[]
}

/** preload 暴露的 API；没有 Electron 外壳时 window.bologui 不存在。 */
export interface BologuiApi {
  boot(): Promise<BootInfo>
  onEvent(callback: (event: SessionEvent) => void): () => void
}
