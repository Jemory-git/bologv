<script setup lang="ts">
  /**
   * 侧边栏容器：头部、主导航、会话列表、版本号。
   */
  import type { SessionSummary } from '@web/types/view-model.ts'
  import PanelList from '@web/components/sidebar/PanelList.vue'
  import SessionList from '@web/components/sidebar/SessionList.vue'
  import SidebarFooter from '@web/components/sidebar/SidebarFooter.vue'
  import SidebarHeader from '@web/components/sidebar/SidebarHeader.vue'

  defineProps<{ sessions: readonly SessionSummary[]; activeId: string }>()

const emit = defineEmits<{
  (e: 'open-model'): void
}>()
</script>

<template>
  <div class="sidebar-content">
    <SidebarHeader />
    <PanelList />
    <SessionList :sessions="sessions" :active-id="activeId" />
    <SidebarFooter @open-model="emit('open-model')" />
  </div>
</template>

<style scoped lang="scss">
.sidebar-content {
  display: flex;
  flex-direction: column;
  min-height: 0;
  height: 100%;
}
</style>
