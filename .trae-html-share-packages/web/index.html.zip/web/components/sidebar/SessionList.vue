<script setup lang="ts">
  /**
   * 会话列表：唯一滚动区，承载侧边栏的可变内容。
   */
  import type { SessionSummary } from '@web/types/view-model.ts'
  import SessionItem from './SessionItem.vue'

  defineProps<{ sessions: readonly SessionSummary[]; activeId: string }>()
</script>

<template>
  <div class="session-list" role="list" aria-label="会话列表">
    <div class="sidebar-header">
      <div class="row">
        <h2>会话</h2>
        <span class="count">1</span>
      </div>
      <button class="new-chat" type="button" disabled title="多会话将在下一阶段支持">
        ＋ 新建对话
      </button>
    </div>
    <SessionItem v-for="session in sessions" :key="session.id" :session="session" :active="session.id === activeId" />
  </div>
</template>

<style scoped lang="scss">
.session-list {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 0.2rem;
  min-height: 0;
  padding: 0.8rem;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: var(--line) transparent;

  .sidebar-header {
    padding: 1.4rem 1.4rem 1rem;
    border-bottom: 0.1rem solid var(--line);

    .row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.8rem;

      h2 {
        margin: 0;
        color: var(--muted);
        font-size: 1.1rem;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }

      .count {
        padding: 0 0.6rem;
        border-radius: 99.9rem;
        background: var(--panel-2);
        color: var(--muted);
        font: 1.1rem var(--mono);
      }
    }


    .new-chat {
      width: 100%;
      margin-top: 1rem;
      padding: 0.7rem 1rem;
      border: 0.1rem dashed var(--line);
      border-radius: 0.8rem;
      background: transparent;
      color: var(--muted);
      font-size: 1.2rem;
    }
  }
}
</style>
