﻿import type { Plugin } from '@cordis'
import { statusbarItems } from '@web/slots/list/statusbar-items.ts'
import WorkingDirItem from './WorkingDirItem.vue'

export const workingDirItem: Plugin = {
  name: 'working-dir-item',
  apply(ctx) {
    ctx.effect(statusbarItems.register(WorkingDirItem, () => ({})))
  },
}
