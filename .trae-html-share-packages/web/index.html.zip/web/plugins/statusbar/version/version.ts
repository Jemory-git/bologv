﻿import type { Plugin } from '@cordis'
import { statusbarItems } from '@web/slots/list/statusbar-items.ts'
import VersionItem from './VersionItem.vue'

export const versionItem: Plugin = {
  name: 'version-item',
  apply(ctx) {
    ctx.effect(statusbarItems.register(VersionItem, () => ({})))
  },
}
