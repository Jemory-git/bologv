/**
 * 渲染进程侧的 IPC 契约：preload 通过 contextBridge 把 window.miniDsh 暴露给页面。
 * 通道名和载荷类型必须与 apps/electron/src/types/ipc.ts 保持一致。
 */

import type { SessionEvent } from '@contracts'

export type { SessionEvent }

/** boot 通道的返回：插件列表、会话路径、被恢复的历史事件。 */
export interface BootInfo {
  plugins: string[]
  sessionPath: string
  workingDir: string
  restored: SessionEvent[]
}

/** send 通道的返回：本轮对话的最终回答。 */
export interface SendResult {
  answer: string
}

/** preload 暴露的 API；没有 Electron 外壳时 window.miniDsh 不存在。 */
export interface MiniDshApi {
  boot(): Promise<BootInfo>
  send(text: string): Promise<SendResult>
  onEvent(callback: (event: SessionEvent) => void): () => void
}

declare global {
  interface Window {
    miniDsh?: MiniDshApi
  }
}
