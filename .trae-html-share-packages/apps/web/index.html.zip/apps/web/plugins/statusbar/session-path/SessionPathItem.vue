<script setup lang="ts">
import { useAppState } from '@web/plugins/core/app-state.ts'

const { sessionPath } = useAppState()
</script>

<template>
  <span class="item" :title="sessionPath ?? undefined">{{ sessionPath ?? '—' }}</span>
</template>

<style scoped>
.item {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
