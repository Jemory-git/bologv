<script setup lang="ts">
import { useAppState } from '@web/plugins/core/app-state.ts'

const { workingDir } = useAppState()
</script>

<template>
  <span class="item" :title="workingDir ?? undefined">{{ workingDir ?? '—' }}</span>
</template>

<style scoped>
.item {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
