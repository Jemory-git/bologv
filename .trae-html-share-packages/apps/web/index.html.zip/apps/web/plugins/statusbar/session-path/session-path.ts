import type { Plugin } from '@cordis'
import { statusbarItems } from '@web/renderer/slots/list/statusbar-items.ts'
import SessionPathItem from './SessionPathItem.vue'

export const sessionPathItem: Plugin = {
  name: 'session-path-item',
  apply(ctx) {
    ctx.effect(statusbarItems.register(SessionPathItem, () => ({})))
  },
}
