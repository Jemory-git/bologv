/**
 * 应用状态插件：持有启动信息、对话行与发送状态。
 * 组件通过 useAppState() 取用；App.vue 只负责把状态接到布局组件上。
 */

import { computed, shallowRef, type ComputedRef, type ShallowRef } from 'vue'
import type { Plugin } from '@cordis'
import type { BootInfo, SessionEvent } from '@web/contracts.ts'
import { useService } from '@web/use'
import type { TranscriptItem } from '@web/view-model.ts'
import { CONNECTION_SERVICE, type ConnectionService } from './connection.ts'

/** 应用状态的服务名。 */
export const APP_STATE_SERVICE = 'appState'

/** 渲染进程共享的应用状态与动作。 */
export interface AppState {
  readonly boot: ShallowRef<BootInfo | null>
  readonly items: ShallowRef<readonly TranscriptItem[]>
  readonly pending: ShallowRef<boolean>
  readonly sessionPath: ComputedRef<string | null>
  readonly workingDir: ComputedRef<string | null>
  send(text: string): Promise<void>
  clear(): void
}

/**
 * 在组件 setup 中取用应用状态。
 *
 * @returns 由 app-state 插件提供的共享状态。
 */
export function useAppState(): AppState {
  return useService<AppState>(APP_STATE_SERVICE)
}

export const appState: Plugin = {
  name: 'app-state',
  inject: [CONNECTION_SERVICE],
  apply(ctx) {
    const connection = ctx.require<ConnectionService>(CONNECTION_SERVICE)

    const boot = shallowRef<BootInfo | null>(null)
    const items = shallowRef<readonly TranscriptItem[]>([])
    const pending = shallowRef(false)

    const push = (item: TranscriptItem): void => {
      items.value = [...items.value, item]
    }

    const clear = (): void => {
      items.value = []
    }

    const send = async (text: string): Promise<void> => {
      const value = text.trim()
      if (value === '' || pending.value) return
      pending.value = true
      try {
        await connection.send(value)
      } catch (error) {
        push({ kind: 'error', text: `请求失败：${String(error)}` })
      } finally {
        pending.value = false
      }
    }

    ctx.provide<AppState>(APP_STATE_SERVICE, {
      boot,
      items,
      pending,
      sessionPath: computed(() => boot.value?.sessionPath ?? null),
      workingDir: computed(() => boot.value?.workingDir ?? null),
      send,
      clear,
    })

    void connection.boot().then(
      (info) => {
        boot.value = info
        if (info.restored.length > 0) {
          push({ kind: 'notice', text: `已从日志恢复 ${info.restored.length} 条事件。` })
          for (const event of info.restored) push({ kind: 'event', event })
        }
        ctx.effect(connection.onEvent((event: SessionEvent) => push({ kind: 'event', event })))
      },
      (error: unknown) => {
        push({ kind: 'error', text: `启动失败：${String(error)}` })
      },
    )
  },
}
