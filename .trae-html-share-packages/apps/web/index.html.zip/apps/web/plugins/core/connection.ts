/**
 * connection 插件：把 preload 暴露的 window.miniDsh 包装成 Cordis 服务。
 * boot 只真正执行一次，后续插件共享同一份启动信息。
 */

import type { Plugin } from '@cordis'
import type { BootInfo, SessionEvent } from '@web/contracts.ts'

export const CONNECTION_SERVICE = 'connection'

/** 渲染进程访问主进程能力的唯一入口。 */
export interface ConnectionService {
  /** 拉取启动信息；重复调用返回同一个 promise。 */
  boot(): Promise<BootInfo>
  /** 发起一轮对话，返回最终回答。 */
  send(text: string): Promise<string>
  /** 订阅会话事件；返回退订函数。 */
  onEvent(listener: (event: SessionEvent) => void): () => void
}

export const connection: Plugin = {
  name: 'connection',
  apply(ctx) {
    const api = window.miniDsh
    if (api === undefined) {
      throw new Error('window.miniDsh 不可用：请通过 Electron 外壳启动 Web UI')
    }

    let booted: Promise<BootInfo> | undefined
    const service: ConnectionService = {
      boot: () => (booted ??= api.boot()),
      send: async (text) => (await api.send(text)).answer,
      onEvent: (listener) => api.onEvent(listener),
    }
    ctx.provide(CONNECTION_SERVICE, service)
  },
}
