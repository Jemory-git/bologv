/**
 * 渲染进程的视图模型：把会话事件归一化成界面可直接渲染的行。
 * 组件只依赖这里的类型，不直接解释 SessionEvent 的判别字段。
 */

import type { SessionEvent } from './contracts.ts'

/** 对话区的一行：事件、系统提示或错误。 */
export type TranscriptItem =
  | { kind: 'event'; event: SessionEvent }
  | { kind: 'notice'; text: string }
  | { kind: 'error'; text: string }

/** 侧边栏会话条目；当前阶段只有一个默认会话。 */
export interface SessionSummary {
  id: string
  title: string
  subtitle?: string
}
