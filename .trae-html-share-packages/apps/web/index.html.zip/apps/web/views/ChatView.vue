<script setup lang="ts">
/**
 * 对话视图：标题栏、滚动记录与固定输入区。
 */
import type { TranscriptItem } from '@web/view-model.ts'
import ChatHeader from '@web/components/chat/ChatHeader.vue'
import Composer from '@web/components/chat/Composer.vue'
import Transcript from '@web/components/chat/Transcript.vue'

defineProps<{
  items: readonly TranscriptItem[]
  pending: boolean
  title: string
  model: string
}>()

defineEmits<{ send: [text: string]; clear: [] }>()
</script>

<template>
  <section class="chat-view">
    <ChatHeader :title="title" :model="model" :pending="pending" @clear="$emit('clear')" />
    <Transcript :items="items" :pending="pending" @suggest="$emit('send', $event)" />
    <Composer :pending="pending" @send="$emit('send', $event)" />
  </section>
</template>

<style scoped lang="scss">
.chat-view {
  display: flex;
  flex-direction: column;
  min-height: 0;
  height: 100%;
}
</style>
