<script setup lang="ts">
/**
 * 列表型插槽渲染出口：消费 ListSlotDescriptor。
 *
 * 用法：<SlotOutlet :slot="statusbarItems" />
 * descriptor 自身是响应式的，entries 直接 v-for 即可。
 */
import type { ListSlotDescriptor } from '@web/renderer/slots/descriptors.ts'

defineProps<{ slot: ListSlotDescriptor<any> }>()
</script>

<template>
  <component
    v-for="entry in slot.entries"
    :key="entry.id"
    :is="entry.component"
    v-bind="entry.props()"
  />
</template>
