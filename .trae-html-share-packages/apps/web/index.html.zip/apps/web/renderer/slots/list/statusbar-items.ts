/**
 * 状态栏条目列表。
 * 条目组件自己从 AppState / Connection 等 service 取数据，props 留空。
 */
import { ListSlotDescriptor } from '../descriptors.ts'

export const statusbarItems = new ListSlotDescriptor<Record<string, never>>(
  'statusbar.items',
)
