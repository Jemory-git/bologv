/**
 * Chat 面板 header 的动作按钮列表。
 * 位于会话头部右侧，放会话级操作（导出、清空……）。
 */
import { ListSlotDescriptor } from '../descriptors.ts'

export interface ChatHeaderActionsProps {
  pending: boolean
}

export const chatHeaderActions = new ListSlotDescriptor<ChatHeaderActionsProps>(
  'chat.header.actions',
)
