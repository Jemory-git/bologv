<script setup lang="ts">
  /**
   * 输入区：Enter 发送、Shift+Enter 换行，输入框随内容长高。
   */
  import { nextTick, onMounted, ref } from 'vue'
  import SlotOutlet from '@web/renderer/SlotOutlet.vue'
  import { chatComposerActions } from '@web/renderer/slots/list/chat-composer-actions.ts'

  const props = defineProps<{ pending: boolean }>()

  const emit = defineEmits<{ send: [text: string] }>()

  const text = ref('')
  const field = ref<HTMLTextAreaElement | null>(null)

  function resize(): void {
    const element = field.value
    if (element === null) return
    element.style.height = 'auto'
    element.style.height = `${Math.min(element.scrollHeight, 160)}px`
  }

  function submit(): void {
    const value = text.value.trim()
    if (value === '' || props.pending) return
    text.value = ''
    emit('send', value)
    void nextTick(() => {
      resize()
      field.value?.focus()
    })
  }

  function onKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Enter' || event.shiftKey || event.isComposing) return
    event.preventDefault()
    submit()
  }

  onMounted(() => {
    field.value?.focus()
    resize()
  })
</script>

<template>
  <form class="composer" @submit.prevent="submit">
    <div class="box">
      <textarea ref="field" v-model="text" rows="1" autocomplete="off" aria-label="消息输入" placeholder="给 bologui 发消息…" @input="resize" @keydown="onKeydown" />
      <div class="toolbar">
        <SlotOutlet :slot="chatComposerActions" />
        <span class="hint">Enter 发送 · Shift+Enter 换行</span>
        <button type="submit" :disabled="pending || text.trim() === ''">
          {{ pending ? '生成中…' : '发送' }}
        </button>
      </div>
    </div>
  </form>
</template>

<style scoped lang="scss">
.composer {
  padding: 1.2rem 2rem 1.6rem;
  border-top: 0.1rem solid var(--line);
  background: var(--bg);
}

.box {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  padding: 1rem 1.2rem;
  border: 0.1rem solid var(--line);
  border-radius: 1.2rem;
  background: var(--panel);
}

.box:focus-within {
  border-color: var(--accent-line);
}

textarea {
  width: 100%;
  max-height: 16rem;
  padding: 0;
  overflow-y: auto;
  border: 0;
  outline: none;
  background: transparent;
  color: var(--text);
  font: inherit;
  line-height: 1.6;
  resize: none;
}

textarea::placeholder {
  color: var(--muted);
}

.toolbar {
  display: flex;
  align-items: center;
  gap: 0.8rem;
}

.hint {
  margin-left: auto;
  color: var(--muted);
  font-size: 1.1rem;
}

button[type='submit'] {
  padding: 0.5rem 1.2rem;
  border: 0;
  border-radius: 0.7rem;
  background: var(--accent);
  color: #08111d;
  font-size: 1.2rem;
  font-weight: 600;
}

button[type='submit']:disabled {
  opacity: 0.4;
}
</style>
