<script setup lang="ts">
/**
 * 主区域：消费 sidebar.panels 配对插槽的 active view。
 *
 * 从 PairSlotDescriptor.active 直接拿到当前选中的 view，
 * null 表示回到会话页（ChatView）。
 */
import { computed } from 'vue'
import type { TranscriptItem } from '@web/view-model.ts'
import ChatView from '@web/views/ChatView.vue'
import { sidebarPanels } from '@web/renderer/slots/pair/sidebar-panels.ts'

defineProps<{
  items: readonly TranscriptItem[]
  pending: boolean
  title: string
  model: string
}>()

defineEmits<{ send: [text: string]; clear: [] }>()

const activePair = computed(() => sidebarPanels.active.value)
</script>

<template>
  <ChatView
    v-if="activePair === null"
    :items="items"
    :pending="pending"
    :title="title"
    :model="model"
    @send="$emit('send', $event)"
    @clear="$emit('clear')"
  />
  <component
    v-else
    :is="activePair.view.component"
    :key="activePair.id"
    v-bind="activePair.view.props()"
  />
</template>
