<script setup lang="ts">
  /**
   * 侧边栏底部：只保留静态版本号。
   */
</script>

<template>
  <div class="sidebar-footer">
    <span class="version">设置</span>
  </div>
</template>

<style scoped lang="scss">
.sidebar-footer {
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
  padding: 1rem 1.2rem 1.2rem;
  border-top: 0.1rem solid var(--line);
}

.version {
  color: var(--muted);
  font: 1.1rem var(--mono);
}
</style>
