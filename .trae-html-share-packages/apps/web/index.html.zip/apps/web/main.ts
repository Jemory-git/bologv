import './styles/index.scss'
import { createRoot } from '@cordis'
import { appState } from './plugins/core/app-state.ts'
import { connection } from './plugins/core/connection.ts'
import { pluginRegistry } from './plugins/core/plugin-registry.ts'
import { pluginsPage } from './plugins/plugins-page/plugins-page.ts'
import { sessionPathItem } from './plugins/statusbar/session-path/session-path.ts'
import { versionItem } from './plugins/statusbar/version/version.ts'
import { workingDirItem } from './plugins/statusbar/working-dir/working-dir.ts'
import { RENDERER_SERVICE, vueRenderer } from './renderer/vue-renderer.ts'

import { type RendererService } from './renderer/vue-renderer.ts'

async function bootstrap(): Promise<void> {
  const rootCtx = createRoot()
  window.addEventListener('beforeunload', () => rootCtx.close())

  // 纯 TS 服务插件
  await rootCtx.use(vueRenderer)
  await rootCtx.use(connection)
  await rootCtx.use(appState)

  // 插件管理 service + 固定的设置页 UI（不能被用户自己关掉）
  await rootCtx.use(pluginRegistry)
  await rootCtx.use(pluginsPage)

  // 固定的状态栏条目插件（基础信息，不能被关掉）
  // await rootCtx.use(workingDirItem)
  // await rootCtx.use(sessionPathItem)
  // await rootCtx.use(versionItem)

  // 可切换的 UI 插件由 registry 按 localStorage / defaultEnabled 自动加载

  rootCtx.require<RendererService>(RENDERER_SERVICE).mount()
}

void bootstrap()
