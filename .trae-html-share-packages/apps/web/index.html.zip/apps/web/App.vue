<script setup lang="ts">
  /**
   * 组合根：把插件状态接到布局组件上，App.vue 本身不持有业务状态。
   */
  import { computed } from 'vue'
  import { useAppState } from './plugins/core/app-state.ts'

  import AppShell from './components/layout/AppShell.vue'
  import Sidebar from './components/layout/Sidebar.vue'
  import StatusBar from './components/layout/StatusBar.vue'
  import TitleBar from './components/layout/TitleBar.vue'
  import MainPanel from './components/layout/MainPanel.vue'

  import type { SessionSummary } from './view-model.ts'

  const state = useAppState()
  const { items, pending, sessionPath } = state

  const sessions = computed<SessionSummary[]>(() => {
    const path = sessionPath.value
    return [
      {
        id: 'default',
        title: '当前会话',
        ...(path === null ? {} : { subtitle: path.split(/[\\/]/).slice(-2).join('/') }),
      },
    ]
  })

  function send(text: string): void {
    void state.send(text)
  }
</script>

<template>
  <AppShell>
    <template #titlebar>
      <TitleBar model="mock" :pending="pending" />
    </template>
    <template #sidebar>
      <Sidebar :sessions="sessions" active-id="default" />
    </template>
    <MainPanel :items="items" :pending="pending" title="当前会话" model="mock" @send="send" @clear="state.clear" />
    <template #statusbar>
      <StatusBar />
    </template>
  </AppShell>
</template>
